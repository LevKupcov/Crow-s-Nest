<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регентство - Прокат экипажей</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Merriweather:wght@300;400;700&family=Cinzel:wght@400;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    
    <main>
        <?php include 'includes/hero.php'; ?>
        <?php include 'includes/fleet.php'; ?>
        <?php include 'includes/how-it-works.php'; ?>
        <?php include 'includes/pricing.php'; ?>
    </main>
    
    <?php include 'includes/footer.php'; ?>
</body>
</html>


