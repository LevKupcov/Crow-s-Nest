<?php
$plans = [
    [
        'name' => 'Стандарт',
        'subtitle' => 'Для случайных поездок',
        'price' => 'Без платы',
        'period' => 'Оплата по мере использования',
        'features' => [
            '4500₽ за час аренды',
            'Доступ к стандартному парку',
            'Комплексное страхование включено',
            'Круглосуточная служба поддержки',
            'Бесплатные зоны парковки'
        ],
        'featured' => false,
        'icon' => null
    ],
    [
        'name' => 'Премиум',
        'subtitle' => 'Для регулярных путешественников',
        'price' => '19900₽',
        'period' => 'Месячная подписка',
        'features' => [
            '3500₽ за час аренды',
            'Доступ ко всей коллекции',
            'Премиальное страхование',
            'Приоритетное обслуживание',
            'Бесплатные зоны парковки',
            '10 бесплатных часов ежемесячно',
            '15% скидка на топливо',
            'Привилегия предварительного бронирования'
        ],
        'featured' => true,
        'icon' => 'crown'
    ],
    [
        'name' => 'Представительский',
        'subtitle' => 'Для корпоративных клиентов',
        'price' => 'Индивидуально',
        'period' => 'Персональные условия',
        'features' => [
            'Индивидуальные условия обслуживания',
            'Неограниченный доступ к парку',
            'Комплексное страхование КАСКО',
            'Персональный менеджер',
            'Бесплатные зоны парковки',
            'Корпоративная отчётность',
            'Выделенная линия поддержки',
            'Гибкие условия оплаты',
            'Услуги шофёра доступны'
        ],
        'featured' => false,
        'icon' => 'award'
    ]
];
?>
<section id="pricing" class="py-20 relative damask-pattern" style="background-color: var(--color-cream);">
    <div class="container">
        <div class="section-header">
            <div class="section-ornament">
                <span style="color: var(--color-gold); font-size: 1.875rem;">❦</span>
                <div class="section-ornament-line"></div>
                <span style="color: var(--color-gold); font-size: 1.875rem;">❧</span>
                <div class="section-ornament-line"></div>
                <span style="color: var(--color-gold); font-size: 1.875rem;">❦</span>
            </div>
            <h2 class="text-shadow-vintage mb-4">
                Тарифы и планы
            </h2>
            <p class="text-xl" style="color: var(--color-charcoal); max-width: 42rem; margin: 0 auto; font-style: italic;">
                Выберите план, наилучшим образом отвечающий вашим потребностям
            </p>
            <div class="flourish-divider mt-6"></div>
        </div>
        
        <div class="grid md:grid-cols-3 gap-8">
            <?php foreach ($plans as $index => $plan): ?>
            <div class="pricing-card relative <?php echo $plan['featured'] ? 'featured' : ''; ?>">
                <?php if ($plan['featured']): ?>
                <div class="popular-badge absolute" style="top: -2.5rem; left: 50%; transform: translateX(-50%); background-color: var(--color-burgundy); color: var(--color-gold); padding: 0.75rem 2rem; border: 2px solid var(--color-gold); z-index: 20; box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1); white-space: nowrap;">
                    <span style="letter-spacing: 0.1em; font-size: 0.875rem; display: flex; align-items: center; gap: 0.5rem; font-family: var(--font-family-accent);">
                        <svg class="icon-sm" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                        </svg>
                        Самый популярный
                        <svg class="icon-sm" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                        </svg>
                    </span>
                </div>
                <?php endif; ?>
                
                <div class="vintage-frame pricing-card-inner h-full flex flex-col" style="<?php echo $plan['featured'] ? 'background-color: var(--color-parchment); box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);' : 'background-color: white;'; ?>">
                    <div style="padding: 2rem; flex: 1; display: flex; flex-direction: column;">
                        <!-- Header -->
                        <div class="text-center mb-8 pb-8" style="border-bottom: 2px solid var(--color-gold);">
                            <?php if ($plan['icon']): ?>
                            <div class="inline-flex items-center justify-center mb-4" style="width: 4rem; height: 4rem; border-radius: 50%; border: 2px solid var(--color-gold); background-color: var(--color-burgundy);">
                                <?php if ($plan['icon'] == 'crown'): ?>
                                    <svg class="icon-lg" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                                    </svg>
                                <?php elseif ($plan['icon'] == 'award'): ?>
                                    <svg class="icon-lg" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                                    </svg>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="inline-block mb-4" style="background-color: var(--color-burgundy); color: var(--color-gold); padding: 0.5rem 1rem; border: 1px solid var(--color-gold);">
                                <span style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-family: var(--font-family-accent);">
                                    <?php echo htmlspecialchars($plan['subtitle']); ?>
                                </span>
                            </div>
                            <h3 class="mb-4"><?php echo htmlspecialchars($plan['name']); ?></h3>
                            <div class="flex flex-col items-center gap-2">
                                <span style="font-size: 3rem; color: var(--color-burgundy); font-family: var(--font-family-heading);">
                                    <?php echo htmlspecialchars($plan['price']); ?>
                                </span>
                                <span style="color: var(--color-sepia); font-style: italic;"><?php echo htmlspecialchars($plan['period']); ?></span>
                            </div>
                        </div>
                        
                        <!-- Features -->
                        <ul style="margin-bottom: 2rem; flex: 1; list-style: none;">
                            <?php foreach ($plan['features'] as $feature): ?>
                            <li class="flex items-start gap-3" style="margin-bottom: 1rem;">
                                <svg class="icon-sm flex-shrink-0 mt-1" style="color: var(--color-burgundy);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                </svg>
                                <span style="color: var(--color-charcoal);"><?php echo htmlspecialchars($feature); ?></span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        
                        <!-- CTA Button -->
                        <button class="pricing-btn w-full py-4 border-2 tracking-wider transition-all shadow-md" style="
                            background-color: white; 
                            color: var(--color-burgundy); 
                            border-color: var(--color-burgundy);
                            font-family: var(--font-family-accent);
                            letter-spacing: 0.05em;
                            cursor: pointer;
                        ">
                            <?php echo $plan['price'] === 'Индивидуально' ? 'Направить запрос' : 'Выбрать план'; ?>
                        </button>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Additional note -->
        <div class="mt-16 text-center" style="max-width: 42rem; margin-left: auto; margin-right: auto;">
            <div style="border-top: 2px solid var(--color-gold); border-bottom: 2px solid var(--color-gold); padding: 1.5rem 0;">
                <p style="color: var(--color-charcoal); font-style: italic;">
                    Все тарифы включают комплексное страхование, техническое обслуживание и круглосуточную 
                    помощь на дороге. Применяются дополнительные условия. Пожалуйста, обратитесь за подробной информацией.
                </p>
            </div>
        </div>
    </div>
</section>

