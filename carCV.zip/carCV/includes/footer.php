<footer class="bg-[var(--color-burgundy)] border-t-4 border-[var(--color-gold)] relative damask-pattern">
    <div style="height: 0.5rem; background: linear-gradient(to right, transparent, var(--color-gold), transparent);"></div>
    
    <div class="container" style="padding: 4rem 1rem;">
        <div class="grid md:grid-cols-4 gap-12 mb-12">
            <!-- Brand -->
            <div>
                <div class="flex items-center gap-3 mb-4">
                    <svg class="icon-lg" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                    </svg>
                    <div>
                        <h3 style="color: var(--color-gold); font-family: var(--font-family-accent);">
                            Регентство
                        </h3>
                        <p style="color: var(--color-antique-gold); font-size: 0.75rem; letter-spacing: 0.1em; text-transform: uppercase;">
                            Каршеринг
                        </p>
                    </div>
                </div>
                <p style="color: var(--color-cream); margin-bottom: 1.5rem; font-style: italic;">
                    Предоставляем премиальные услуги каршеринга с 2025 года.
                </p>
                <div class="flex gap-4">
                    <?php
                    $socialIcons = [
                        ['name' => 'facebook', 'path' => 'M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z'],
                        ['name' => 'twitter', 'path' => 'M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z'],
                        ['name' => 'instagram', 'path' => 'M16 2H8a6 6 0 00-6 6v8a6 6 0 006 6h8a6 6 0 006-6V8a6 6 0 00-6-6zm0 2a4 4 0 014 4v8a4 4 0 01-4 4H8a4 4 0 01-4-4V8a4 4 0 014-4h8zm-4 3a5 5 0 100 10 5 5 0 000-10zm0 2a3 3 0 110 6 3 3 0 010-6zm5-1a1 1 0 100 2 1 1 0 000-2z']
                    ];
                    foreach ($socialIcons as $icon):
                    ?>
                    <a href="#" style="width: 2.5rem; height: 2.5rem; border: 2px solid var(--color-gold); display: flex; align-items: center; justify-content: center; transition: all 0.3s; text-decoration: none;">
                        <svg class="icon" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="<?php echo $icon['path']; ?>" />
                        </svg>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <!-- Quick Links -->
            <div>
                <h4 style="color: var(--color-gold); margin-bottom: 1.5rem; text-transform: uppercase; letter-spacing: 0.05em; padding-bottom: 0.5rem; border-bottom: 2px solid var(--color-gold); font-family: var(--font-family-accent);">
                    Навигация
                </h4>
                <ul style="list-style: none;">
                    <?php
                    $navLinks = ['О нашем сервисе', 'Наш парк', 'Условия обслуживания', 'Правила и положения', 'Вакансии'];
                    foreach ($navLinks as $link):
                    ?>
                    <li style="margin-bottom: 0.75rem;">
                        <a href="#" style="color: var(--color-cream); transition: color 0.3s; display: flex; align-items: center; gap: 0.5rem; text-decoration: none;">
                            <span style="color: var(--color-gold);">❧</span>
                            <?php echo htmlspecialchars($link); ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <!-- Support -->
            <div>
                <h4 style="color: var(--color-gold); margin-bottom: 1.5rem; text-transform: uppercase; letter-spacing: 0.05em; padding-bottom: 0.5rem; border-bottom: 2px solid var(--color-gold); font-family: var(--font-family-accent);">
                    Поддержка
                </h4>
                <ul style="list-style: none;">
                    <?php
                    $supportLinks = ['Служба клиентов', 'Частые вопросы', 'Контактная информация', 'Отзывы', 'Партнёрство'];
                    foreach ($supportLinks as $link):
                    ?>
                    <li style="margin-bottom: 0.75rem;">
                        <a href="#" style="color: var(--color-cream); transition: color 0.3s; display: flex; align-items: center; gap: 0.5rem; text-decoration: none;">
                            <span style="color: var(--color-gold);">❧</span>
                            <?php echo htmlspecialchars($link); ?>
                        </a>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            
            <!-- Contact -->
            <div>
                <h4 style="color: var(--color-gold); margin-bottom: 1.5rem; text-transform: uppercase; letter-spacing: 0.05em; padding-bottom: 0.5rem; border-bottom: 2px solid var(--color-gold); font-family: var(--font-family-accent);">
                    Связь
                </h4>
                <ul style="list-style: none;">
                    <li class="flex items-start gap-3" style="color: var(--color-cream); margin-bottom: 1rem;">
                        <svg class="icon-sm flex-shrink-0 mt-1" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                        </svg>
                        <div>
                            <div>+7 (800) 555-35-35</div>
                            <div style="font-size: 0.875rem; color: var(--color-antique-gold); font-style: italic;">Доступны в любое время</div>
                        </div>
                    </li>
                    <li class="flex items-start gap-3" style="color: var(--color-cream); margin-bottom: 1rem;">
                        <svg class="icon-sm flex-shrink-0 mt-1" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                        <div>info@regentstvo-motors.ru</div>
                    </li>
                    <li class="flex items-start gap-3" style="color: var(--color-cream);">
                        <svg class="icon-sm flex-shrink-0 mt-1" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                        </svg>
                        <div>
                            Площадь Тверская, д. 1<br />
                            Москва, 125009
                        </div>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Ornamental divider -->
        <div class="flex items-center justify-center gap-4 my-8">
            <div style="height: 1px; background-color: var(--color-gold); flex: 1;"></div>
            <span style="color: var(--color-gold); font-size: 1.5rem;">❦</span>
            <div style="height: 1px; background-color: var(--color-gold); flex: 1;"></div>
        </div>
        
        <!-- Bottom bar -->
        <div class="flex flex-col md:flex-row justify-between items-center gap-4" style="color: var(--color-antique-gold);">
            <div style="text-transform: uppercase; letter-spacing: 0.05em; font-size: 0.875rem; font-family: var(--font-family-accent);">
                © 2025 Регентство Каршеринг. Все права защищены.
            </div>
            <div class="flex gap-6" style="font-size: 0.875rem;">
                <a href="#" style="color: var(--color-antique-gold); transition: color 0.3s; text-decoration: none;">Политика конфиденциальности</a>
                <span style="color: var(--color-gold);">•</span>
                <a href="#" style="color: var(--color-antique-gold); transition: color 0.3s; text-decoration: none;">Условия использования</a>
                <span style="color: var(--color-gold);">•</span>
                <a href="#" style="color: var(--color-antique-gold); transition: color 0.3s; text-decoration: none;">Политика Cookie</a>
            </div>
        </div>
        
        <!-- Decorative seal -->
        <div style="margin-top: 2rem; display: flex; justify-content: center;">
            <div style="width: 4rem; height: 4rem; border-radius: 50%; border: 4px solid var(--color-gold); display: flex; align-items: center; justify-content: center; background-color: var(--color-burgundy);">
                <svg class="icon-lg" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                </svg>
            </div>
        </div>
    </div>
    
    <div style="height: 0.25rem; background-color: var(--color-antique-gold);"></div>
</footer>

