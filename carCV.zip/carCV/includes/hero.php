<section class="relative min-h-screen flex items-center bg-[var(--color-cream)] damask-pattern overflow-hidden">
    <!-- Decorative corner ornaments -->
    <div class="absolute top-0 left-0" style="width: 8rem; height: 8rem; border-top: 4px solid var(--color-gold); border-left: 4px solid var(--color-gold); opacity: 0.3;"></div>
    <div class="absolute top-0 right-0" style="width: 8rem; height: 8rem; border-top: 4px solid var(--color-gold); border-right: 4px solid var(--color-gold); opacity: 0.3;"></div>
    <div class="absolute bottom-0 left-0" style="width: 8rem; height: 8rem; border-bottom: 4px solid var(--color-gold); border-left: 4px solid var(--color-gold); opacity: 0.3;"></div>
    <div class="absolute bottom-0 right-0" style="width: 8rem; height: 8rem; border-bottom: 4px solid var(--color-gold); border-right: 4px solid var(--color-gold); opacity: 0.3;"></div>
    
    <div class="container relative" style="z-index: 10; padding: 5rem 1rem;">
        <div class="grid md:grid-cols-2 gap-16 items-center">
            <div>
                <!-- Ornamental header -->
                <div class="flex items-center gap-3 mb-6">
                    <span style="color: var(--color-gold); font-size: 1.5rem;">❦</span>
                    <p style="color: var(--color-sepia); letter-spacing: 0.1em; text-transform: uppercase; font-size: 0.875rem; font-family: var(--font-family-accent);">
                        Основано в 2025 году
                    </p>
                    <span style="color: var(--color-gold); font-size: 1.5rem;">❦</span>
                </div>
                
                <h1 class="mb-6 text-shadow-vintage">
                    Премиальный каршеринг для взыскательных клиентов
                </h1>
                
                <div class="flourish-divider my-8"></div>
                
                <p class="text-xl mb-8 text-[var(--color-charcoal)] drop-cap" style="font-size: 1.25rem;">
                    Откройте для себя премиальный каршеринг. Наша тщательно подобранная 
                    коллекция автомобилей сочетает классическую элегантность 
                    с современными удобствами и технологиями.
                </p>
                
                <div class="flex flex-wrap gap-4 mb-12">
                    <button class="btn btn-primary">
                        Забронировать автомобиль
                    </button>
                    <button class="btn btn-secondary">
                        Смотреть коллекцию
                    </button>
                </div>
                
                <div class="grid grid-cols-3 gap-6">
                    <?php
                    $stats = [
                        ['icon' => 'clock', 'label' => 'Круглосуточно', 'value' => 'К вашим услугам'],
                        ['icon' => 'award', 'label' => 'Премиум качество', 'value' => 'С 2025 года'],
                        ['icon' => 'shield', 'label' => 'Застрахованы', 'value' => 'Полностью']
                    ];
                    foreach ($stats as $stat):
                    ?>
                    <div class="text-center">
                        <div class="inline-flex items-center justify-center" style="width: 4rem; height: 4rem; border-radius: 50%; border: 2px solid var(--color-gold); background-color: var(--color-cream); margin-bottom: 0.75rem;">
                            <?php if ($stat['icon'] == 'clock'): ?>
                                <svg class="icon-lg" style="color: var(--color-burgundy);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>
                            <?php elseif ($stat['icon'] == 'award'): ?>
                                <svg class="icon-lg" style="color: var(--color-burgundy);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                                </svg>
                            <?php elseif ($stat['icon'] == 'shield'): ?>
                                <svg class="icon-lg" style="color: var(--color-burgundy);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                                </svg>
                            <?php endif; ?>
                        </div>
                        <div style="font-size: 0.75rem; color: var(--color-sepia); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.25rem; font-family: var(--font-family-accent);">
                            <?php echo $stat['label']; ?>
                        </div>
                        <div style="font-size: 0.875rem; color: var(--color-charcoal);"><?php echo $stat['value']; ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            
            <div class="relative">
                <!-- Victorian frame -->
                <div class="vintage-frame p-4 bg-[var(--color-cream)]">
                    <div class="relative">
                        <img 
                            src="https://images.unsplash.com/photo-1657093416463-28ba3bf295c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwY2xhc3NpYyUyMGNhcnxlbnwxfHx8fDE3NjQ1Mjk2MDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral" 
                            alt="Vintage automobile" 
                            style="width: 100%; box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25); filter: sepia(0.15) contrast(1.1);"
                            onerror="this.onerror=null; this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODgiIGhlaWdodD0iODgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBvcGFjaXR5PSIuMyIgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIzLjciPjxyZWN0IHg9IjE2IiB5PSIxNiIgd2lkdGg9IjU2IiBoZWlnaHQ9IjU2IiByeD0iNiIvPjxwYXRoIGQ9Im0xNiA1OCAxNi0xOCAzMiAzMiIvPjxjaXJjbGUgY3g9IjUzIiBjeT0iMzUiIHI9IjciLz48L3N2Zz4KCg==';"
                        />
                        <!-- Corner ornaments -->
                        <div class="absolute -top-3 -left-3" style="width: 1.5rem; height: 1.5rem; border-top: 2px solid var(--color-gold); border-left: 2px solid var(--color-gold);"></div>
                        <div class="absolute -top-3 -right-3" style="width: 1.5rem; height: 1.5rem; border-top: 2px solid var(--color-gold); border-right: 2px solid var(--color-gold);"></div>
                        <div class="absolute -bottom-3 -left-3" style="width: 1.5rem; height: 1.5rem; border-bottom: 2px solid var(--color-gold); border-left: 2px solid var(--color-gold);"></div>
                        <div class="absolute -bottom-3 -right-3" style="width: 1.5rem; height: 1.5rem; border-bottom: 2px solid var(--color-gold); border-right: 2px solid var(--color-gold);"></div>
                    </div>
                </div>
                
                <!-- Decorative ribbon -->
                <div class="absolute -bottom-6 -right-6" style="background-color: var(--color-burgundy); color: var(--color-gold); padding: 0.75rem 2rem; border: 2px solid var(--color-gold); box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1); transform: rotate(3deg);">
                    <p style="letter-spacing: 0.1em; font-size: 0.875rem; font-family: var(--font-family-accent);">EST. 2025</p>
                </div>
            </div>
        </div>
    </div>
</section>

