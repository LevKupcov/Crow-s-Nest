<header class="bg-[var(--color-burgundy)] border-b-4 border-[var(--color-gold)] relative damask-pattern">
    <!-- Decorative top border -->
    <div class="h-2 bg-gradient-to-r from-transparent via-[var(--color-gold)] to-transparent"></div>
    
    <div class="container">
        <div class="flex items-center justify-between" style="padding: 1.5rem 0;">
            <!-- Logo -->
            <div class="flex items-center gap-3">
                <div class="relative">
                    <svg class="icon-xl" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                    </svg>
                    <div class="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-[var(--color-gold)] border-2 border-[var(--color-burgundy)]"></div>
                </div>
                <div>
                    <h1 style="font-size: 1.875rem; color: var(--color-gold); letter-spacing: 0.025em; font-family: var(--font-family-accent);">
                        Регентство
                    </h1>
                    <p style="color: var(--color-antique-gold); font-size: 0.75rem; letter-spacing: 0.1em; text-transform: uppercase; font-family: var(--font-family-body);">
                        Каршеринг
                    </p>
                </div>
            </div>
            
            <!-- Navigation -->
            <nav class="hidden md:flex gap-8 items-center">
                <a href="#fleet" style="color: var(--color-cream); transition: color 0.3s; letter-spacing: 0.025em;">Наш парк</a>
                <a href="#how" style="color: var(--color-cream); transition: color 0.3s; letter-spacing: 0.025em;">Как это работает</a>
                <a href="#pricing" style="color: var(--color-cream); transition: color 0.3s; letter-spacing: 0.025em;">Тарифы</a>
                <button class="btn btn-primary" style="background-color: var(--color-gold); color: var(--color-burgundy); border-color: var(--color-antique-gold); padding: 0.75rem 1.5rem; display: flex; align-items: center; gap: 0.5rem;">
                    <svg class="icon-sm" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                    <span>Войти</span>
                </button>
            </nav>
            
            <button class="md:hidden" style="color: var(--color-gold);">
                <svg class="icon-lg" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
        </div>
    </div>
    
    <!-- Decorative bottom border -->
    <div style="height: 0.25rem; background-color: var(--color-antique-gold);"></div>
</header>

