<?php
$cars = [
    [
        'name' => 'Аристократ',
        'category' => 'Роскошный седан',
        'price' => '4500₽/час',
        'image' => 'https://images.unsplash.com/photo-1721994234246-45087e5aca16?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB2aW50YWdlJTIwYXV0b21vYmlsZXxlbnwxfHx8fDE3NjQ2MDU2NjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        'specs' => ['5 пассажиров', 'Автоматическая', 'Климат-контроль'],
        'description' => 'Отличный выбор для комфортных поездок',
        'featured' => false
    ],
    [
        'name' => 'Джентльменское купе',
        'category' => 'Спортивный туризм',
        'price' => '8500₽/час',
        'image' => 'https://images.unsplash.com/photo-1524457006207-092fa5d972bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGFzc2ljJTIwY2FyJTIwZWxlZ2FudHxlbnwxfHx8fDE3NjQ2MDU2NjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        'specs' => ['2 пассажира', 'Механическая', 'Кожаный салон'],
        'description' => 'Для тех, кто ценит удовольствие от вождения',
        'featured' => true
    ],
    [
        'name' => 'Гранд-турер',
        'category' => 'Роскошный универсал',
        'price' => '6500₽/час',
        'image' => 'https://images.unsplash.com/photo-1616416460012-b35c710aaa83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbnRpcXVlJTIwY2FyJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzY0NjA1NjYwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
        'specs' => ['4 пассажира', 'Просторный', 'Деревянная отделка'],
        'description' => 'Комфорт и элегантность для дальних поездок',
        'featured' => false
    ]
];
?>
<section id="fleet" class="py-20 relative" style="background-color: var(--color-parchment);">
    <div class="container">
        <!-- Section header -->
        <div class="section-header">
            <div class="section-ornament">
                <span style="color: var(--color-gold); font-size: 1.875rem;">❦</span>
                <div class="section-ornament-line"></div>
                <span style="color: var(--color-gold); font-size: 1.875rem;">❧</span>
                <div class="section-ornament-line"></div>
                <span style="color: var(--color-gold); font-size: 1.875rem;">❦</span>
            </div>
            <h2 class="text-shadow-vintage mb-4">
                Наш автопарк
            </h2>
            <p class="text-xl" style="color: var(--color-charcoal); max-width: 42rem; margin: 0 auto; font-style: italic;">
                Тщательно подобранная коллекция автомобилей на любой случай
            </p>
            <div class="flourish-divider mt-6"></div>
        </div>
        
        <!-- Cars grid -->
        <div class="grid md:grid-cols-3 gap-8">
            <?php foreach ($cars as $index => $car): ?>
            <div class="group relative">
                <?php if ($car['featured']): ?>
                <div class="absolute" style="top: -2.5rem; left: 50%; transform: translateX(-50%); z-index: 20; background-color: var(--color-gold); color: var(--color-burgundy); padding: 0.5rem 1.5rem; border: 2px solid var(--color-burgundy); box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -4px rgba(0, 0, 0, 0.1); white-space: nowrap;">
                    <div class="flex items-center gap-2" style="font-family: var(--font-family-accent);">
                        <svg class="icon-sm" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                        </svg>
                        <span style="letter-spacing: 0.05em; font-size: 0.875rem;">Самый популярный</span>
                        <svg class="icon-sm" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
                        </svg>
                    </div>
                </div>
                <?php endif; ?>
                
                <div class="vintage-frame bg-[var(--color-cream)] hover-scale shadow-lg" style="transition: all 0.3s;">
                    <div style="padding: 0.5rem;">
                        <!-- Image -->
                        <div class="relative overflow-hidden mb-4" style="border: 2px solid var(--color-antique-gold);">
                            <img 
                                src="<?php echo htmlspecialchars($car['image']); ?>" 
                                alt="<?php echo htmlspecialchars($car['name']); ?>"
                                style="width: 100%; height: 16rem; object-fit: cover; filter: sepia(0.1);"
                                onerror="this.onerror=null; this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iODgiIGhlaWdodD0iODgiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgc3Ryb2tlPSIjMDAwIiBzdHJva2UtbGluZWpvaW49InJvdW5kIiBvcGFjaXR5PSIuMyIgZmlsbD0ibm9uZSIgc3Ryb2tlLXdpZHRoPSIzLjciPjxyZWN0IHg9IjE2IiB5PSIxNiIgd2lkdGg9IjU2IiBoZWlnaHQ9IjU2IiByeD0iNiIvPjxwYXRoIGQ9Im0xNiA1OCAxNi0xOCAzMiAzMiIvPjxjaXJjbGUgY3g9IjUzIiBjeT0iMzUiIHI9IjciLz48L3N2Zz4KCg==';"
                            />
                            <div class="absolute inset-0" style="background: linear-gradient(to top, rgba(58, 58, 58, 0.4), transparent, transparent);"></div>
                        </div>
                        
                        <!-- Content -->
                        <div style="padding: 0 1rem 1rem;">
                            <div class="text-center mb-4">
                                <div class="inline-block mb-3" style="background-color: var(--color-burgundy); color: var(--color-gold); padding: 0.25rem 1rem; border: 1px solid var(--color-gold);">
                                    <span style="font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.1em; font-family: var(--font-family-accent);">
                                        <?php echo htmlspecialchars($car['category']); ?>
                                    </span>
                                </div>
                                <h3 class="mb-2"><?php echo htmlspecialchars($car['name']); ?></h3>
                                <p style="font-size: 0.875rem; color: var(--color-sepia); font-style: italic;"><?php echo htmlspecialchars($car['description']); ?></p>
                            </div>
                            
                            <div style="border-top: 2px solid var(--color-gold); border-bottom: 2px solid var(--color-gold); padding: 0.75rem 0; margin-bottom: 1rem;">
                                <div class="flex flex-wrap gap-2 justify-center">
                                    <?php foreach ($car['specs'] as $spec): ?>
                                    <span style="font-size: 0.75rem; color: var(--color-charcoal); background-color: var(--color-parchment); padding: 0.25rem 0.75rem; border: 1px solid var(--color-antique-gold);">
                                        <?php echo htmlspecialchars($spec); ?>
                                    </span>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            
                            <div class="flex items-center justify-between">
                                <div>
                                    <div style="font-size: 0.75rem; color: var(--color-sepia); text-transform: uppercase; letter-spacing: 0.025em; font-family: var(--font-family-accent);">
                                        От
                                    </div>
                                    <div style="font-size: 1.5rem; color: var(--color-burgundy); font-family: var(--font-family-heading);">
                                        <?php echo htmlspecialchars($car['price']); ?>
                                    </div>
                                </div>
                                <button class="fleet-btn btn" style="padding: 0.75rem 1.5rem; font-family: var(--font-family-accent); box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1); background-color: white; color: var(--color-burgundy); border: 2px solid var(--color-burgundy);">
                                    Забронировать
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

