<?php
$steps = [
    [
        'icon' => 'book',
        'title' => 'Регистрация',
        'description' => 'Заполните простую форму регистрации, чтобы создать учётную запись',
        'number' => 'I'
    ],
    [
        'icon' => 'map',
        'title' => 'Выбор автомобиля',
        'description' => 'Ознакомьтесь с нашей коллекцией и выберите автомобиль, который подходит вам',
        'number' => 'II'
    ],
    [
        'icon' => 'key',
        'title' => 'Получение и отправление',
        'description' => 'Прибудьте в назначенное место и начните своё путешествие',
        'number' => 'III'
    ],
    [
        'icon' => 'check',
        'title' => 'Возвращение автомобиля',
        'description' => 'Верните автомобиль в любое из наших пунктов в удобное для вас время',
        'number' => 'IV'
    ]
];
?>
<section id="how" class="py-20 relative damask-pattern" style="background-color: var(--color-burgundy); border-top: 4px solid var(--color-gold); border-bottom: 4px solid var(--color-gold);">
    <div class="container">
        <div class="section-header">
            <div class="section-ornament">
                <span style="color: var(--color-gold); font-size: 1.875rem;">❦</span>
                <div class="section-ornament-line"></div>
                <span style="color: var(--color-gold); font-size: 1.875rem;">❧</span>
                <div class="section-ornament-line"></div>
                <span style="color: var(--color-gold); font-size: 1.875rem;">❦</span>
            </div>
            <h2 style="color: var(--color-gold); margin-bottom: 1rem;">
                Как это работает
            </h2>
            <p class="text-xl" style="color: var(--color-cream); max-width: 42rem; margin: 0 auto; font-style: italic;">
                Четыре простых шага к началу вашего путешествия
            </p>
        </div>
        
        <div class="grid md:grid-cols-4 gap-8 relative">
            <!-- Connecting ornamental line -->
            <div class="hidden md:block absolute" style="top: 5rem; left: 0; right: 0;">
                <div style="height: 1px; background-color: var(--color-gold); opacity: 0.3;"></div>
            </div>
            
            <?php foreach ($steps as $index => $step): ?>
            <div class="relative">
                <div class="flex flex-col items-center text-center">
                    <!-- Icon badge -->
                    <div class="relative" style="margin-bottom: 2rem;">
                        <div class="flex items-center justify-center" style="width: 8rem; height: 8rem; border: 4px solid var(--color-gold); border-radius: 50%; background-color: var(--color-burgundy); position: relative; z-index: 10;">
                            <?php
                            $iconSvg = '';
                            switch ($step['icon']) {
                                case 'book':
                                    $iconSvg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />';
                                    break;
                                case 'map':
                                    $iconSvg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" />';
                                    break;
                                case 'key':
                                    $iconSvg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />';
                                    break;
                                case 'check':
                                    $iconSvg = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />';
                                    break;
                            }
                            ?>
                            <svg class="icon-xl" style="color: var(--color-gold);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <?php echo $iconSvg; ?>
                            </svg>
                        </div>
                        <!-- Decorative corners -->
                        <div class="absolute top-0 left-0" style="width: 1rem; height: 1rem; border-top: 2px solid var(--color-antique-gold); border-left: 2px solid var(--color-antique-gold);"></div>
                        <div class="absolute top-0 right-0" style="width: 1rem; height: 1rem; border-top: 2px solid var(--color-antique-gold); border-right: 2px solid var(--color-antique-gold);"></div>
                        <div class="absolute bottom-0 left-0" style="width: 1rem; height: 1rem; border-bottom: 2px solid var(--color-antique-gold); border-left: 2px solid var(--color-antique-gold);"></div>
                        <div class="absolute bottom-0 right-0" style="width: 1rem; height: 1rem; border-bottom: 2px solid var(--color-antique-gold); border-right: 2px solid var(--color-antique-gold);"></div>
                    </div>
                    
                    <!-- Roman numeral between icon and text -->
                    <div style="margin-bottom: 1.5rem;">
                        <div style="background-color: var(--color-gold); color: var(--color-burgundy); padding: 0.5rem 1rem; border: 2px solid var(--color-burgundy); display: inline-block;">
                            <span style="font-size: 1.25rem; font-family: var(--font-family-accent);">
                                <?php echo $step['number']; ?>
                            </span>
                        </div>
                    </div>
                    
                    <h4 style="color: var(--color-gold); margin-bottom: 0.75rem;"><?php echo htmlspecialchars($step['title']); ?></h4>
                    <p style="color: var(--color-cream);"><?php echo htmlspecialchars($step['description']); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <!-- Testimonial section -->
        <div class="mt-20" style="max-width: 48rem; margin-left: auto; margin-right: auto;">
            <div class="vintage-frame bg-[var(--color-cream)] p-8">
                <div class="text-center">
                    <span style="color: var(--color-gold); font-size: 3rem; line-height: 1;">"</span>
                    <p class="text-xl italic my-4" style="color: var(--color-charcoal);">
                        Отличный сервис! Автомобили содержатся в идеальном состоянии, 
                        а удобство использования действительно на высшем уровне.
                    </p>
                    <span style="color: var(--color-gold); font-size: 3rem; line-height: 1;">"</span>
                    <div style="margin-top: 1.5rem; padding-top: 1.5rem; border-top: 2px solid var(--color-gold);">
                        <p style="color: var(--color-burgundy); font-family: var(--font-family-accent);">
                            Эдмунд Хартли
                        </p>
                        <p style="font-size: 0.875rem; color: var(--color-sepia);">Постоянный клиент</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

