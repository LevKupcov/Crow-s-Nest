import { ImageWithFallback } from './figma/ImageWithFallback';
import { Users, Gauge, Star } from "lucide-react";

const cars = [
  {
    name: "Аристократ",
    category: "Роскошный седан",
    price: "4500₽/час",
    image: "https://images.unsplash.com/photo-1721994234246-45087e5aca16?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjB2aW50YWdlJTIwYXV0b21vYmlsZXxlbnwxfHx8fDE3NjQ2MDU2NjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    specs: ["5 пассажиров", "Автоматическая", "Климат-контроль"],
    description: "Достойный выбор для утончённого путешественника"
  },
  {
    name: "Джентльменское купе",
    category: "Спортивный туризм",
    price: "8500₽/час",
    image: "https://images.unsplash.com/photo-1524457006207-092fa5d972bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjbGFzc2ljJTIwY2FyJTIwZWxlZ2FudHxlbnwxfHx8fDE3NjQ2MDU2NjB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    specs: ["2 пассажира", "Механическая", "Кожаный салон"],
    featured: true,
    description: "Для тех, кто ценит живой моторинг"
  },
  {
    name: "Гранд-турер",
    category: "Роскошный универсал",
    price: "6500₽/час",
    image: "https://images.unsplash.com/photo-1616416460012-b35c710aaa83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbnRpcXVlJTIwY2FyJTIwaW50ZXJpb3J8ZW58MXx8fHwxNzY0NjA1NjYwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    specs: ["4 пассажира", "Просторный", "Деревянная отделка"],
    description: "Комфорт и элегантность для дальних поездок"
  }
];

export function Fleet() {
  return (
    <section id="fleet" className="py-20 relative bg-[var(--color-parchment)]">
      <div className="max-w-7xl mx-auto px-4">
        {/* Section header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-4 mb-4">
            <span className="text-[var(--color-gold)] text-3xl">❦</span>
            <div className="h-px bg-[var(--color-gold)] w-24"></div>
            <span className="text-[var(--color-gold)] text-3xl">❧</span>
            <div className="h-px bg-[var(--color-gold)] w-24"></div>
            <span className="text-[var(--color-gold)] text-3xl">❦</span>
          </div>
          <h2 className="text-shadow-vintage mb-4">
            Наш благородный парк
          </h2>
          <p className="text-xl text-[var(--color-charcoal)] max-w-2xl mx-auto italic">
            Тщательно подобранная коллекция моторных экипажей на любой случай
          </p>
          <div className="flourish-divider mt-6"></div>
        </div>
        
        {/* Cars grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {cars.map((car, index) => (
            <div key={index} className="group relative">
              {car.featured && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-20 bg-[var(--color-gold)] text-[var(--color-burgundy)] px-6 py-2 border-2 border-[var(--color-burgundy)] shadow-lg">
                  <div className="flex items-center gap-2" style={{ fontFamily: 'var(--font-family-accent)' }}>
                    <Star className="w-4 h-4 fill-current" />
                    <span className="tracking-wider text-sm">Самый популярный</span>
                    <Star className="w-4 h-4 fill-current" />
                  </div>
                </div>
              )}
              
              <div className="vintage-frame bg-[var(--color-cream)] hover:shadow-2xl transition-all duration-300">
                <div className="p-2">
                  {/* Image */}
                  <div className="relative overflow-hidden mb-4 border-2 border-[var(--color-antique-gold)]">
                    <ImageWithFallback
                      src={car.image}
                      alt={car.name}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-700"
                      style={{ filter: 'sepia(0.1)' }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-charcoal)]/40 via-transparent to-transparent"></div>
                  </div>
                  
                  {/* Content */}
                  <div className="px-4 pb-4">
                    <div className="text-center mb-4">
                      <div className="inline-block bg-[var(--color-burgundy)] text-[var(--color-gold)] px-4 py-1 mb-3 border border-[var(--color-gold)]">
                        <span className="text-xs uppercase tracking-widest" style={{ fontFamily: 'var(--font-family-accent)' }}>
                          {car.category}
                        </span>
                      </div>
                      <h3 className="mb-2">{car.name}</h3>
                      <p className="text-sm text-[var(--color-sepia)] italic">{car.description}</p>
                    </div>
                    
                    <div className="border-t-2 border-[var(--color-gold)] border-b-2 py-3 mb-4">
                      <div className="flex flex-wrap gap-2 justify-center">
                        {car.specs.map((spec, i) => (
                          <span key={i} className="text-xs text-[var(--color-charcoal)] bg-[var(--color-parchment)] px-3 py-1 border border-[var(--color-antique-gold)]">
                            {spec}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-xs text-[var(--color-sepia)] uppercase tracking-wide" style={{ fontFamily: 'var(--font-family-accent)' }}>
                          От
                        </div>
                        <div className="text-2xl text-[var(--color-burgundy)]" style={{ fontFamily: 'var(--font-family-heading)' }}>
                          {car.price}
                        </div>
                      </div>
                      <button className="bg-[var(--color-burgundy)] text-[var(--color-cream)] px-6 py-3 border-2 border-[var(--color-gold)] hover:bg-[var(--color-wine)] transition-all shadow-md" style={{ fontFamily: 'var(--font-family-accent)' }}>
                        Забронировать
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}