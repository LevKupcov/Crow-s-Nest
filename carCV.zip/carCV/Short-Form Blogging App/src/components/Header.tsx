import { Menu, Crown, User } from "lucide-react";

export function Header() {
  return (
    <header className="bg-[var(--color-burgundy)] border-b-4 border-[var(--color-gold)] relative damask-pattern">
      {/* Decorative top border */}
      <div className="h-2 bg-gradient-to-r from-transparent via-[var(--color-gold)] to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="relative">
              <Crown className="text-[var(--color-gold)] w-12 h-12" strokeWidth={1.5} />
              <div className="absolute -bottom-1 -right-1 w-3 h-3 rounded-full bg-[var(--color-gold)] border-2 border-[var(--color-burgundy)]"></div>
            </div>
            <div>
              <h1 className="text-3xl text-[var(--color-gold)] tracking-wide" style={{ fontFamily: 'var(--font-family-accent)' }}>
                Регентство
              </h1>
              <p className="text-[var(--color-antique-gold)] text-xs tracking-widest uppercase" style={{ fontFamily: 'var(--font-family-body)' }}>
                Прокат экипажей
              </p>
            </div>
          </div>
          
          {/* Navigation */}
          <nav className="hidden md:flex gap-8 items-center">
            <a href="#fleet" className="text-[var(--color-cream)] hover:text-[var(--color-gold)] transition-colors tracking-wide">Наш парк</a>
            <a href="#how" className="text-[var(--color-cream)] hover:text-[var(--color-gold)] transition-colors tracking-wide">Как это работает</a>
            <a href="#pricing" className="text-[var(--color-cream)] hover:text-[var(--color-gold)] transition-colors tracking-wide">Тарифы</a>
            <button className="bg-[var(--color-gold)] text-[var(--color-burgundy)] px-6 py-3 border-2 border-[var(--color-antique-gold)] hover:bg-[var(--color-antique-gold)] transition-all tracking-wide flex items-center gap-2 shadow-lg">
              <User className="w-4 h-4" />
              <span style={{ fontFamily: 'var(--font-family-accent)' }}>Войти</span>
            </button>
          </nav>
          
          <button className="md:hidden text-[var(--color-gold)]">
            <Menu className="w-8 h-8" />
          </button>
        </div>
      </div>
      
      {/* Decorative bottom border */}
      <div className="h-1 bg-[var(--color-antique-gold)]"></div>
    </header>
  );
}