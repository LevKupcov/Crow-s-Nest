import { ImageWithFallback } from './figma/ImageWithFallback';
import { Clock, Award, Shield } from "lucide-react";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center bg-[var(--color-cream)] damask-pattern overflow-hidden">
      {/* Decorative corner ornaments */}
      <div className="absolute top-0 left-0 w-32 h-32 border-t-4 border-l-4 border-[var(--color-gold)] opacity-30"></div>
      <div className="absolute top-0 right-0 w-32 h-32 border-t-4 border-r-4 border-[var(--color-gold)] opacity-30"></div>
      <div className="absolute bottom-0 left-0 w-32 h-32 border-b-4 border-l-4 border-[var(--color-gold)] opacity-30"></div>
      <div className="absolute bottom-0 right-0 w-32 h-32 border-b-4 border-r-4 border-[var(--color-gold)] opacity-30"></div>
      
      <div className="max-w-7xl mx-auto px-4 py-20 relative z-10">
        <div className="grid md:grid-cols-2 gap-16 items-center">
          <div>
            {/* Ornamental header */}
            <div className="flex items-center gap-3 mb-6">
              <span className="text-[var(--color-gold)] text-2xl">❦</span>
              <p className="text-[var(--color-sepia)] tracking-widest uppercase text-sm" style={{ fontFamily: 'var(--font-family-accent)' }}>
                Основано в 2025 году
              </p>
              <span className="text-[var(--color-gold)] text-2xl">❦</span>
            </div>
            
            <h1 className="mb-6 text-shadow-vintage">
              Изысканный моторинг для благородных путешественников
            </h1>
            
            <div className="flourish-divider my-8"></div>
            
            <p className="text-xl mb-8 text-[var(--color-charcoal)] drop-cap">
              Познайте превосходство в прокате моторных экипажей. Наша тщательно подобранная 
              коллекция автомобилей сочетает в себе вневременную элегантность прошлых лет 
              с современными удобствами, ожидаемыми сегодняшними взыскательными господами и дамами.
            </p>
            
            <div className="flex flex-wrap gap-4 mb-12">
              <button className="bg-[var(--color-burgundy)] text-[var(--color-cream)] px-10 py-4 border-2 border-[var(--color-gold)] hover:bg-[var(--color-wine)] transition-all tracking-wider shadow-lg" style={{ fontFamily: 'var(--font-family-accent)' }}>
                Забронировать экипаж
              </button>
              <button className="bg-transparent text-[var(--color-burgundy)] px-10 py-4 border-2 border-[var(--color-burgundy)] hover:bg-[var(--color-burgundy)] hover:text-[var(--color-cream)] transition-all tracking-wider" style={{ fontFamily: 'var(--font-family-accent)' }}>
                Смотреть коллекцию
              </button>
            </div>
            
            <div className="grid grid-cols-3 gap-6">
              {[
                { icon: Clock, label: "Круглосуточно", value: "К вашим услугам" },
                { icon: Award, label: "Премиум качество", value: "С 2025 года" },
                { icon: Shield, label: "Застрахованы", value: "Полностью" }
              ].map((stat, index) => (
                <div key={index} className="text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full border-2 border-[var(--color-gold)] bg-[var(--color-cream)] mb-3">
                    <stat.icon className="w-8 h-8 text-[var(--color-burgundy)]" strokeWidth={1.5} />
                  </div>
                  <div className="text-xs text-[var(--color-sepia)] uppercase tracking-wide mb-1" style={{ fontFamily: 'var(--font-family-accent)' }}>
                    {stat.label}
                  </div>
                  <div className="text-sm text-[var(--color-charcoal)]">{stat.value}</div>
                </div>
              ))}
            </div>
          </div>
          
          <div className="relative">
            {/* Victorian frame */}
            <div className="vintage-frame p-4 bg-[var(--color-cream)]">
              <div className="relative">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1657093416463-28ba3bf295c9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx2aW50YWdlJTIwY2xhc3NpYyUyMGNhcnxlbnwxfHx8fDE3NjQ1Mjk2MDZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Vintage automobile"
                  className="w-full shadow-2xl"
                  style={{ filter: 'sepia(0.15) contrast(1.1)' }}
                />
                {/* Corner ornaments */}
                <div className="absolute -top-3 -left-3 w-6 h-6 border-t-2 border-l-2 border-[var(--color-gold)]"></div>
                <div className="absolute -top-3 -right-3 w-6 h-6 border-t-2 border-r-2 border-[var(--color-gold)]"></div>
                <div className="absolute -bottom-3 -left-3 w-6 h-6 border-b-2 border-l-2 border-[var(--color-gold)]"></div>
                <div className="absolute -bottom-3 -right-3 w-6 h-6 border-b-2 border-r-2 border-[var(--color-gold)]"></div>
              </div>
            </div>
            
            {/* Decorative ribbon */}
            <div className="absolute -bottom-6 -right-6 bg-[var(--color-burgundy)] text-[var(--color-gold)] px-8 py-3 border-2 border-[var(--color-gold)] shadow-xl transform rotate-3">
              <p className="tracking-widest text-sm" style={{ fontFamily: 'var(--font-family-accent)' }}>EST. 2025</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}