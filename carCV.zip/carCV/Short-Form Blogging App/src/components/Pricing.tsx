import { Check, Crown, Award } from "lucide-react";

const plans = [
  {
    name: "Стандарт",
    subtitle: "Для случайных поездок",
    price: "Без платы",
    period: "Оплата по мере использования",
    features: [
      "4500₽ за час аренды",
      "Доступ к стандартному парку",
      "Комплексное страхование включено",
      "Круглосуточная служба поддержки",
      "Бесплатные зоны парковки"
    ],
    icon: null
  },
  {
    name: "Премиум",
    subtitle: "Для регулярных путешественников",
    price: "19900₽",
    period: "Месячная подписка",
    features: [
      "3500₽ за час аренды",
      "Доступ ко всей коллекции",
      "Премиальное страхование",
      "Приоритетное обслуживание",
      "Бесплатные зоны парковки",
      "10 бесплатных часов ежемесячно",
      "15% скидка на топливо",
      "Привилегия предварительного бронирования"
    ],
    featured: true,
    icon: Crown
  },
  {
    name: "Представительский",
    subtitle: "Для благородных особ",
    price: "Индивидуально",
    period: "Персональные условия",
    features: [
      "Индивидуальные условия обслуживания",
      "Неограниченный доступ к парку",
      "Комплексное страхование КАСКО",
      "Персональный менеджер",
      "Бесплатные зоны парковки",
      "Корпоративная отчётность",
      "Выделенная линия поддержки",
      "Гибкие условия оплаты",
      "Услуги шофёра доступны"
    ],
    icon: Award
  }
];

export function Pricing() {
  return (
    <section id="pricing" className="py-20 relative bg-[var(--color-cream)] damask-pattern">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-4 mb-4">
            <span className="text-[var(--color-gold)] text-3xl">❦</span>
            <div className="h-px bg-[var(--color-gold)] w-24"></div>
            <span className="text-[var(--color-gold)] text-3xl">❧</span>
            <div className="h-px bg-[var(--color-gold)] w-24"></div>
            <span className="text-[var(--color-gold)] text-3xl">❦</span>
          </div>
          <h2 className="text-shadow-vintage mb-4">
            Условия обслуживания
          </h2>
          <p className="text-xl text-[var(--color-charcoal)] max-w-2xl mx-auto italic">
            Выберите план, наилучшим образом отвечающий вашим потребностям
          </p>
          <div className="flourish-divider mt-6"></div>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index} 
              className={`relative ${plan.featured ? 'md:-translate-y-4' : ''}`}
            >
              {plan.featured && (
                <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-[var(--color-burgundy)] text-[var(--color-gold)] px-8 py-3 border-2 border-[var(--color-gold)] z-20 shadow-xl">
                  <span className="tracking-widest text-sm flex items-center gap-2" style={{ fontFamily: 'var(--font-family-accent)' }}>
                    <Crown className="w-4 h-4" />
                    Самый популярный
                    <Crown className="w-4 h-4" />
                  </span>
                </div>
              )}
              
              <div className={`vintage-frame ${plan.featured ? 'bg-[var(--color-parchment)] shadow-2xl' : 'bg-white'} h-full flex flex-col`}>
                <div className="p-8 flex-1 flex flex-col">
                  {/* Header */}
                  <div className="text-center mb-8 pb-8 border-b-2 border-[var(--color-gold)]">
                    {plan.icon && (
                      <div className="inline-flex items-center justify-center w-16 h-16 rounded-full border-2 border-[var(--color-gold)] bg-[var(--color-burgundy)] mb-4">
                        <plan.icon className="w-8 h-8 text-[var(--color-gold)]" />
                      </div>
                    )}
                    <div className="inline-block bg-[var(--color-burgundy)] text-[var(--color-gold)] px-4 py-2 mb-4 border border-[var(--color-gold)]">
                      <span className="text-xs uppercase tracking-widest" style={{ fontFamily: 'var(--font-family-accent)' }}>
                        {plan.subtitle}
                      </span>
                    </div>
                    <h3 className="mb-4">{plan.name}</h3>
                    <div className="flex flex-col items-center gap-2">
                      <span className="text-5xl text-[var(--color-burgundy)]" style={{ fontFamily: 'var(--font-family-heading)' }}>
                        {plan.price}
                      </span>
                      <span className="text-[var(--color-sepia)] italic">{plan.period}</span>
                    </div>
                  </div>
                  
                  {/* Features */}
                  <ul className="space-y-4 mb-8 flex-1">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-[var(--color-burgundy)] flex-shrink-0 mt-1" strokeWidth={2} />
                        <span className="text-[var(--color-charcoal)]">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  {/* CTA Button */}
                  <button className={`w-full py-4 border-2 tracking-wider transition-all shadow-md ${
                    plan.featured 
                      ? 'bg-[var(--color-burgundy)] text-[var(--color-gold)] border-[var(--color-gold)] hover:bg-[var(--color-wine)]' 
                      : 'bg-transparent text-[var(--color-burgundy)] border-[var(--color-burgundy)] hover:bg-[var(--color-burgundy)] hover:text-[var(--color-cream)]'
                  }`} style={{ fontFamily: 'var(--font-family-accent)' }}>
                    {plan.price === "Индивидуально" ? "Направить запрос" : "Выбрать план"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Additional note */}
        <div className="mt-16 text-center max-w-2xl mx-auto">
          <div className="border-t-2 border-b-2 border-[var(--color-gold)] py-6">
            <p className="text-[var(--color-charcoal)] italic">
              Все тарифы включают комплексное страхование, техническое обслуживание и круглосуточную 
              помощь на дороге. Применяются дополнительные условия. Пожалуйста, обратитесь за подробной информацией.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
