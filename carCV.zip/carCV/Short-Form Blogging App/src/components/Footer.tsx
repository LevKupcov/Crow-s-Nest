import { Crown, Mail, Phone, MapPin, Facebook, Twitter, Instagram } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-[var(--color-burgundy)] border-t-4 border-[var(--color-gold)] relative damask-pattern">
      <div className="h-2 bg-gradient-to-r from-transparent via-[var(--color-gold)] to-transparent"></div>
      
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-3 mb-4">
              <Crown className="text-[var(--color-gold)] w-10 h-10" />
              <div>
                <h3 className="text-[var(--color-gold)]" style={{ fontFamily: 'var(--font-family-accent)' }}>
                  Регентство
                </h3>
                <p className="text-[var(--color-antique-gold)] text-xs tracking-widest uppercase">
                  Моторные экипажи
                </p>
              </div>
            </div>
            <p className="text-[var(--color-cream)] mb-6 italic">
              Предоставляем благородные услуги проката моторных экипажей дамам и господам 
              взыскательного вкуса с 2025 года.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram].map((Icon, i) => (
                <a 
                  key={i}
                  href="#" 
                  className="w-10 h-10 border-2 border-[var(--color-gold)] hover:bg-[var(--color-gold)] flex items-center justify-center transition-all group"
                >
                  <Icon className="w-5 h-5 text-[var(--color-gold)] group-hover:text-[var(--color-burgundy)] transition-colors" strokeWidth={1.5} />
                </a>
              ))}
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-[var(--color-gold)] mb-6 uppercase tracking-wider pb-2 border-b-2 border-[var(--color-gold)]" style={{ fontFamily: 'var(--font-family-accent)' }}>
              Навигация
            </h4>
            <ul className="space-y-3">
              {['О нашем сервисе', 'Наш парк', 'Условия обслуживания', 'Правила и положения', 'Вакансии'].map((link, i) => (
                <li key={i}>
                  <a href="#" className="text-[var(--color-cream)] hover:text-[var(--color-gold)] transition-colors flex items-center gap-2">
                    <span className="text-[var(--color-gold)]">❧</span>
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Support */}
          <div>
            <h4 className="text-[var(--color-gold)] mb-6 uppercase tracking-wider pb-2 border-b-2 border-[var(--color-gold)]" style={{ fontFamily: 'var(--font-family-accent)' }}>
              Поддержка
            </h4>
            <ul className="space-y-3">
              {['Служба клиентов', 'Частые вопросы', 'Контактная информация', 'Отзывы', 'Партнёрство'].map((link, i) => (
                <li key={i}>
                  <a href="#" className="text-[var(--color-cream)] hover:text-[var(--color-gold)] transition-colors flex items-center gap-2">
                    <span className="text-[var(--color-gold)]">❧</span>
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="text-[var(--color-gold)] mb-6 uppercase tracking-wider pb-2 border-b-2 border-[var(--color-gold)]" style={{ fontFamily: 'var(--font-family-accent)' }}>
              Связь
            </h4>
            <ul className="space-y-4">
              <li className="flex items-start gap-3 text-[var(--color-cream)]">
                <Phone className="w-5 h-5 text-[var(--color-gold)] flex-shrink-0 mt-1" strokeWidth={1.5} />
                <div>
                  <div>+7 (800) 555-35-35</div>
                  <div className="text-sm text-[var(--color-antique-gold)] italic">Доступны в любое время</div>
                </div>
              </li>
              <li className="flex items-start gap-3 text-[var(--color-cream)]">
                <Mail className="w-5 h-5 text-[var(--color-gold)] flex-shrink-0 mt-1" strokeWidth={1.5} />
                <div>info@regentstvo-motors.ru</div>
              </li>
              <li className="flex items-start gap-3 text-[var(--color-cream)]">
                <MapPin className="w-5 h-5 text-[var(--color-gold)] flex-shrink-0 mt-1" strokeWidth={1.5} />
                <div>
                  Площадь Тверская, д. 1<br />
                  Москва, 125009
                </div>
              </li>
            </ul>
          </div>
        </div>
        
        {/* Ornamental divider */}
        <div className="flex items-center justify-center gap-4 my-8">
          <div className="h-px bg-[var(--color-gold)] flex-1"></div>
          <span className="text-[var(--color-gold)] text-2xl">❦</span>
          <div className="h-px bg-[var(--color-gold)] flex-1"></div>
        </div>
        
        {/* Bottom bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-[var(--color-antique-gold)]">
          <div className="uppercase tracking-wider text-sm" style={{ fontFamily: 'var(--font-family-accent)' }}>
            © 2025 Регентство Прокат Моторных Экипажей. Все права защищены.
          </div>
          <div className="flex gap-6 text-sm">
            <a href="#" className="hover:text-[var(--color-gold)] transition-colors">Политика конфиденциальности</a>
            <span className="text-[var(--color-gold)]">•</span>
            <a href="#" className="hover:text-[var(--color-gold)] transition-colors">Условия использования</a>
            <span className="text-[var(--color-gold)]">•</span>
            <a href="#" className="hover:text-[var(--color-gold)] transition-colors">Политика Cookie</a>
          </div>
        </div>
        
        {/* Decorative seal */}
        <div className="mt-8 flex justify-center">
          <div className="w-16 h-16 rounded-full border-4 border-[var(--color-gold)] flex items-center justify-center bg-[var(--color-burgundy)]">
            <Crown className="w-8 h-8 text-[var(--color-gold)]" strokeWidth={1.5} />
          </div>
        </div>
      </div>
      
      <div className="h-1 bg-[var(--color-antique-gold)]"></div>
    </footer>
  );
}
