import { BookOpen, Map, KeyRound, CheckCircle2 } from "lucide-react";

const steps = [
  {
    icon: BookOpen,
    title: "Регистрация",
    description: "Заполните простую форму регистрации, чтобы создать учётную запись в нашем благородном сервисе",
    number: "I"
  },
  {
    icon: Map,
    title: "Выбор экипажа",
    description: "Ознакомьтесь с нашей коллекцией и выберите моторный экипаж, наилучшим образом отвечающий вашим требованиям",
    number: "II"
  },
  {
    icon: KeyRound,
    title: "Получение и отправление",
    description: "Прибудьте в назначенное место и начните своё путешествие с подобающим стилем",
    number: "III"
  },
  {
    icon: CheckCircle2,
    title: "Возвращение с честью",
    description: "Верните экипаж в любое из наших утверждённых мест в удобное для вас время",
    number: "IV"
  }
];

export function HowItWorks() {
  return (
    <section id="how" className="py-20 relative bg-[var(--color-burgundy)] damask-pattern border-y-4 border-[var(--color-gold)]">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-4 mb-4">
            <span className="text-[var(--color-gold)] text-3xl">❦</span>
            <div className="h-px bg-[var(--color-gold)] w-24"></div>
            <span className="text-[var(--color-gold)] text-3xl">❧</span>
            <div className="h-px bg-[var(--color-gold)] w-24"></div>
            <span className="text-[var(--color-gold)] text-3xl">❦</span>
          </div>
          <h2 className="text-[var(--color-gold)] mb-4">
            Процесс взаимодействия
          </h2>
          <p className="text-xl text-[var(--color-cream)] max-w-2xl mx-auto italic">
            Четыре простых шага к началу вашего путешествия
          </p>
        </div>
        
        <div className="grid md:grid-cols-4 gap-8 relative">
          {/* Connecting ornamental line */}
          <div className="hidden md:block absolute top-20 left-0 right-0">
            <div className="h-px bg-[var(--color-gold)] opacity-30"></div>
          </div>
          
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="flex flex-col items-center text-center">
                {/* Roman numeral badge */}
                <div className="relative mb-6">
                  <div className="w-32 h-32 border-4 border-[var(--color-gold)] rounded-full flex items-center justify-center bg-[var(--color-burgundy)] relative z-10 damask-pattern">
                    <step.icon className="w-12 h-12 text-[var(--color-gold)]" strokeWidth={1.5} />
                  </div>
                  <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 bg-[var(--color-gold)] text-[var(--color-burgundy)] px-4 py-2 z-20 border-2 border-[var(--color-burgundy)]">
                    <span className="text-xl" style={{ fontFamily: 'var(--font-family-accent)' }}>
                      {step.number}
                    </span>
                  </div>
                  {/* Decorative corners */}
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-[var(--color-antique-gold)]"></div>
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-[var(--color-antique-gold)]"></div>
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-[var(--color-antique-gold)]"></div>
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-[var(--color-antique-gold)]"></div>
                </div>
                
                <h4 className="mb-3 text-[var(--color-gold)] mt-4">{step.title}</h4>
                <p className="text-[var(--color-cream)]">{step.description}</p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Testimonial section */}
        <div className="mt-20 max-w-3xl mx-auto">
          <div className="vintage-frame bg-[var(--color-cream)] p-8">
            <div className="text-center">
              <span className="text-[var(--color-gold)] text-5xl leading-none">"</span>
              <p className="text-xl text-[var(--color-charcoal)] italic my-4">
                Превосходнейший сервис! Моторные экипажи содержатся в идеальном состоянии, 
                а удобство, предоставляемое современному путешественнику, поистине не имеет себе равных.
              </p>
              <span className="text-[var(--color-gold)] text-5xl leading-none">"</span>
              <div className="mt-6 pt-6 border-t-2 border-[var(--color-gold)]">
                <p className="text-[var(--color-burgundy)]" style={{ fontFamily: 'var(--font-family-accent)' }}>
                  Лорд Эдмунд Хартли
                </p>
                <p className="text-sm text-[var(--color-sepia)]">Достопочтенный покровитель</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}