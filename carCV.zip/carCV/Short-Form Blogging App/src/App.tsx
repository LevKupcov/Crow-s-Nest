import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { Fleet } from "./components/Fleet";
import { HowItWorks } from "./components/HowItWorks";
import { Pricing } from "./components/Pricing";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-[var(--color-parchment)]">
      <Header />
      <main>
        <Hero />
        <Fleet />
        <HowItWorks />
        <Pricing />
      </main>
      <Footer />
    </div>
  );
}
