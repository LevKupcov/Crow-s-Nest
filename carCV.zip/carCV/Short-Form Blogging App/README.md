
  # Short-Form Blogging App

  This is a code bundle for Short-Form Blogging App. The original project is available at https://www.figma.com/design/tFTanZivv3cr7j4ZtXvgtm/Short-Form-Blogging-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  